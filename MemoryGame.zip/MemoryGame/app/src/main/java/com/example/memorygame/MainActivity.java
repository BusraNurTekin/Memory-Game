package com.example.memorygame;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    TextView score;
    ImageView picture1, picture2, picture3, picture4;
    ImageView picture11, picture12, picture13, picture14;
    ImageView picture21, picture22, picture23, picture24;
    ImageView picture31, picture32, picture33, picture34;
    ImageView picture41, picture42, picture43, picture44;

    int turn = 1;
    int playerScore = 0;
    int numberOfCards = 1;
    int fCard; //first card
    int sCard; //second card

    int sFCard; //select first card
    int sSCard; //select second card

    int image101, image102, image103, image104, image105, image106, image107, image108, image109, image110;
    int image201, image202, image203, image204, image205, image206, image207, image208, image209, image210;

    Integer[] gameCards = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        score = (TextView) findViewById(R.id.score);

        picture1 = (ImageView) findViewById(R.id.p1);
        picture2 = (ImageView) findViewById(R.id.p2);
        picture3 = (ImageView) findViewById(R.id.p3);
        picture4 = (ImageView) findViewById(R.id.p4);
        picture11 = (ImageView) findViewById(R.id.p11);
        picture12 = (ImageView) findViewById(R.id.p12);
        picture13 = (ImageView) findViewById(R.id.p13);
        picture14 = (ImageView) findViewById(R.id.p14);
        picture21 = (ImageView) findViewById(R.id.p21);
        picture22 = (ImageView) findViewById(R.id.p22);
        picture23 = (ImageView) findViewById(R.id.p23);
        picture24 = (ImageView) findViewById(R.id.p24);
        picture31 = (ImageView) findViewById(R.id.p31);
        picture32 = (ImageView) findViewById(R.id.p32);
        picture33 = (ImageView) findViewById(R.id.p33);
        picture34 = (ImageView) findViewById(R.id.p34);
        picture41 = (ImageView) findViewById(R.id.p41);
        picture42 = (ImageView) findViewById(R.id.p42);
        picture43 = (ImageView) findViewById(R.id.p43);
        picture44 = (ImageView) findViewById(R.id.p44);

        picture1.setTag("0");
        picture2.setTag("1");
        picture3.setTag("2");
        picture4.setTag("3");
        picture11.setTag("4");
        picture12.setTag("5");
        picture13.setTag("6");
        picture14.setTag("7");
        picture21.setTag("8");
        picture22.setTag("9");
        picture23.setTag("10");
        picture24.setTag("11");
        picture31.setTag("12");
        picture32.setTag("13");
        picture33.setTag("14");
        picture34.setTag("15");
        picture41.setTag("16");
        picture42.setTag("17");
        picture43.setTag("18");
        picture44.setTag("19");

        frontOfCards();
        Collections.shuffle(Arrays.asList(gameCards));

        picture1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture1, card);
            }
        });
        picture2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture2, card);
            }
        });
        picture3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture3, card);
            }
        });
        picture4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture4, card);
            }
        });
        picture11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture11, card);
            }
        });
        picture12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture12, card);
            }
        });
        picture13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture13, card);
            }
        });
        picture14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture14, card);
            }
        });
        picture21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture21, card);
            }
        });
        picture22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture22, card);
            }
        });
        picture23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture23, card);
            }
        });
        picture24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture24, card);
            }
        });
        picture31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture31, card);
            }
        });
        picture32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture32, card);
            }
        });
        picture33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture33, card);
            }
        });
        picture34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture34, card);
            }
        });
        picture41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture41, card);
            }
        });
        picture42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture42, card);
            }
        });
        picture43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture43, card);
            }
        });
        picture44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int card = Integer.parseInt((String) v.getTag());
                motion(picture44, card);
            }
        });
    }

    private void motion(ImageView IV, int card) {
        if (gameCards[card] == 101) {
            IV.setImageResource(image101);
        }
        else if (gameCards[card] == 102) {
            IV.setImageResource(image102);
        }
        else if (gameCards[card] == 103) {
            IV.setImageResource(image103);
        }
        else if (gameCards[card] == 104) {
            IV.setImageResource(image104);
        }
        else if (gameCards[card] == 105) {
            IV.setImageResource(image105);
        }
        else if (gameCards[card] == 106) {
            IV.setImageResource(image106);
        }
        else if (gameCards[card] == 107) {
            IV.setImageResource(image107);
        }
        else if (gameCards[card] == 108) {
            IV.setImageResource(image108);
        }
        else if (gameCards[card] == 109) {
            IV.setImageResource(image109);
        }
        else if (gameCards[card] == 110) {
            IV.setImageResource(image110);
        }
        else if (gameCards[card] == 201) {
            IV.setImageResource(image201);
        }
        else if (gameCards[card] == 202) {
            IV.setImageResource(image202);
        }
        else if (gameCards[card] == 203) {
            IV.setImageResource(image203);
        }
        else if (gameCards[card] == 204) {
            IV.setImageResource(image204);
        }
        else if (gameCards[card] == 205) {
            IV.setImageResource(image205);
        }
        else if (gameCards[card] == 206) {
            IV.setImageResource(image206);
        }
        else if (gameCards[card] == 207) {
            IV.setImageResource(image207);
        }
        else if (gameCards[card] == 208) {
            IV.setImageResource(image208);
        }
        else if (gameCards[card] == 209) {
            IV.setImageResource(image209);
        }
        else if (gameCards[card] == 210) {
            IV.setImageResource(image210);
        }

        if (numberOfCards == 1) {
            fCard = gameCards[card];
            if (fCard > 200) {
                fCard = fCard - 100;
            }
            numberOfCards = 2;
            sFCard = card;
            IV.setEnabled(false);
        }
        else if (numberOfCards == 2) {
            sCard = gameCards[card];
            if (sCard > 200) {
                sCard = sCard - 100;
            }
            numberOfCards = 1;
            sSCard = card;

            picture1.setEnabled(false);
            picture2.setEnabled(false);
            picture3.setEnabled(false);
            picture4.setEnabled(false);
            picture11.setEnabled(false);
            picture12.setEnabled(false);
            picture13.setEnabled(false);
            picture14.setEnabled(false);
            picture21.setEnabled(false);
            picture22.setEnabled(false);
            picture23.setEnabled(false);
            picture24.setEnabled(false);
            picture31.setEnabled(false);
            picture32.setEnabled(false);
            picture33.setEnabled(false);
            picture34.setEnabled(false);
            picture41.setEnabled(false);
            picture42.setEnabled(false);
            picture43.setEnabled(false);
            picture44.setEnabled(false);

            Handler h = new Handler();
            h.postDelayed(new Runnable() {

                @Override
                public void run() {
                    calculate();
                }
            }, 1000);
        }

    }
    public void calculate() {
        if (fCard == sCard) {
            if (sFCard == 0) {
                picture1.setVisibility(View.INVISIBLE);
            } else if (sFCard == 1) {
                picture2.setVisibility(View.INVISIBLE);
            } else if (sFCard == 2) {
                picture3.setVisibility(View.INVISIBLE);
            } else if (sFCard == 3) {
                picture4.setVisibility(View.INVISIBLE);
            } else if (sFCard == 4) {
                picture11.setVisibility(View.INVISIBLE);
            } else if (sFCard == 5) {
                picture12.setVisibility(View.INVISIBLE);
            } else if (sFCard == 6) {
                picture13.setVisibility(View.INVISIBLE);
            } else if (sFCard == 7) {
                picture14.setVisibility(View.INVISIBLE);
            } else if (sFCard == 8) {
                picture21.setVisibility(View.INVISIBLE);
            } else if (sFCard == 9) {
                picture22.setVisibility(View.INVISIBLE);
            } else if (sFCard == 10) {
                picture23.setVisibility(View.INVISIBLE);
            } else if (sFCard == 11) {
                picture24.setVisibility(View.INVISIBLE);
            } else if (sFCard == 12) {
                picture31.setVisibility(View.INVISIBLE);
            } else if (sFCard == 13) {
                picture32.setVisibility(View.INVISIBLE);
            } else if (sFCard == 14) {
                picture33.setVisibility(View.INVISIBLE);
            } else if (sFCard == 15) {
                picture34.setVisibility(View.INVISIBLE);
            } else if (sFCard == 16) {
                picture41.setVisibility(View.INVISIBLE);
            } else if (sFCard == 17) {
                picture42.setVisibility(View.INVISIBLE);
            } else if (sFCard == 18) {
                picture43.setVisibility(View.INVISIBLE);
            } else if (sFCard == 19) {
                picture44.setVisibility(View.INVISIBLE);
            }


            if (sSCard == 0) {
                picture1.setVisibility(View.INVISIBLE);
            } else if (sSCard == 1) {
                picture2.setVisibility(View.INVISIBLE);
            } else if (sSCard == 2) {
                picture3.setVisibility(View.INVISIBLE);
            } else if (sSCard == 3) {
                picture4.setVisibility(View.INVISIBLE);
            } else if (sSCard == 4) {
                picture11.setVisibility(View.INVISIBLE);
            } else if (sSCard == 5) {
                picture12.setVisibility(View.INVISIBLE);
            } else if (sSCard == 6) {
                picture13.setVisibility(View.INVISIBLE);
            } else if (sSCard == 7) {
                picture14.setVisibility(View.INVISIBLE);
            } else if (sSCard == 8) {
                picture21.setVisibility(View.INVISIBLE);
            } else if (sSCard == 9) {
                picture22.setVisibility(View.INVISIBLE);
            } else if (sSCard == 10) {
                picture23.setVisibility(View.INVISIBLE);
            } else if (sSCard == 11) {
                picture24.setVisibility(View.INVISIBLE);
            } else if (sSCard == 12) {
                picture31.setVisibility(View.INVISIBLE);
            } else if (sSCard == 13) {
                picture32.setVisibility(View.INVISIBLE);
            } else if (sSCard == 14) {
                picture33.setVisibility(View.INVISIBLE);
            } else if (sSCard == 15) {
                picture34.setVisibility(View.INVISIBLE);
            } else if (sSCard == 16) {
                picture41.setVisibility(View.INVISIBLE);
            } else if (sSCard == 17) {
                picture42.setVisibility(View.INVISIBLE);
            } else if (sSCard == 18) {
                picture43.setVisibility(View.INVISIBLE);
            } else if (sSCard == 19) {
                picture44.setVisibility(View.INVISIBLE);
            }

            if (turn == 1) {
                playerScore++;
                score.setText("Score : " + playerScore);
            }
            else {
                picture1.setImageResource(R.drawable.ic_back);
                picture2.setImageResource(R.drawable.ic_back);
                picture3.setImageResource(R.drawable.ic_back);
                picture4.setImageResource(R.drawable.ic_back);
                picture11.setImageResource(R.drawable.ic_back);
                picture12.setImageResource(R.drawable.ic_back);
                picture13.setImageResource(R.drawable.ic_back);
                picture14.setImageResource(R.drawable.ic_back);
                picture21.setImageResource(R.drawable.ic_back);
                picture22.setImageResource(R.drawable.ic_back);
                picture23.setImageResource(R.drawable.ic_back);
                picture24.setImageResource(R.drawable.ic_back);
                picture31.setImageResource(R.drawable.ic_back);
                picture32.setImageResource(R.drawable.ic_back);
                picture33.setImageResource(R.drawable.ic_back);
                picture34.setImageResource(R.drawable.ic_back);
                picture41.setImageResource(R.drawable.ic_back);
                picture42.setImageResource(R.drawable.ic_back);
                picture43.setImageResource(R.drawable.ic_back);
                picture44.setImageResource(R.drawable.ic_back);

            }
            picture1.setEnabled(true);
            picture2.setEnabled(true);
            picture3.setEnabled(true);
            picture4.setEnabled(true);
            picture11.setEnabled(true);
            picture12.setEnabled(true);
            picture13.setEnabled(true);
            picture14.setEnabled(true);
            picture21.setEnabled(true);
            picture22.setEnabled(true);
            picture23.setEnabled(true);
            picture24.setEnabled(true);
            picture31.setEnabled(true);
            picture32.setEnabled(true);
            picture33.setEnabled(true);
            picture34.setEnabled(true);
            picture41.setEnabled(true);
            picture42.setEnabled(true);
            picture43.setEnabled(true);
            picture44.setEnabled(true);

            controlResult();
        }
    }
    private void controlResult() {
        if (picture1.getVisibility() == View.INVISIBLE && picture2.getVisibility() == View.INVISIBLE &&
                picture2.getVisibility() == View.INVISIBLE && picture4.getVisibility() == View.INVISIBLE &&
                picture11.getVisibility() == View.INVISIBLE && picture12.getVisibility() == View.INVISIBLE &&
                picture13.getVisibility() == View.INVISIBLE && picture14.getVisibility() == View.INVISIBLE &&
                picture21.getVisibility() == View.INVISIBLE && picture22.getVisibility() == View.INVISIBLE &&
                picture23.getVisibility() == View.INVISIBLE && picture24.getVisibility() == View.INVISIBLE &&
                picture31.getVisibility() == View.INVISIBLE && picture32.getVisibility() == View.INVISIBLE &&
                picture33.getVisibility() == View.INVISIBLE && picture34.getVisibility() == View.INVISIBLE &&
                picture41.getVisibility() == View.INVISIBLE && picture42.getVisibility() == View.INVISIBLE &&
                picture43.getVisibility() == View.INVISIBLE && picture44.getVisibility() == View.INVISIBLE) {

            AlertDialog.Builder alertDB = new AlertDialog.Builder(MainActivity.this);
            alertDB.setMessage("!Game Over!\nPlayer1 : " + playerScore);
            alertDB.setCancelable(false);
            alertDB.setPositiveButton("New Game", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            })
                    .setNegativeButton("Exit Game", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int i) {
                            finish();
                        }
                    });
            AlertDialog alertDialog = alertDB.create();
            alertDialog.show();
        }

    }

    private void frontOfCards() {
        image101 = R.drawable.ic_image101;
        image102 = R.drawable.ic_image102;
        image103 = R.drawable.ic_image103;
        image104 = R.drawable.ic_image104;
        image105 = R.drawable.ic_image105;
        image106 = R.drawable.ic_image106;
        image107 = R.drawable.ic_image107;
        image108 = R.drawable.ic_image108;
        image109 = R.drawable.ic_image109;
        image110 = R.drawable.ic_image110;
        image201 = R.drawable.ic_image201;
        image202 = R.drawable.ic_image202;
        image203 = R.drawable.ic_image203;
        image204 = R.drawable.ic_image204;
        image205 = R.drawable.ic_image205;
        image206 = R.drawable.ic_image206;
        image207 = R.drawable.ic_image207;
        image208 = R.drawable.ic_image208;
        image209 = R.drawable.ic_image209;
        image210 = R.drawable.ic_image210;
    }
}





